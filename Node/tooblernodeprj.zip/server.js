const express = require("express");
//const socketIo = require("socket.io");
const http = require("http");
const PORT = 8091;
const app = express();
const mongoose = require('./app/config/db.config');
const httpServer = http.createServer(app);
const cors = require("cors");
app.use(cors());
const io = require("socket.io")(httpServer, {
    cors: {
      origin: "http://localhost:3000",
      methods: ["GET", "POST"]
    }
  });

io.on("connection", (socket) => {
  console.log("New client connected");
  
  socket.on('initial_data', () => {
    const docs = 'abcdefg';
    io.sockets.emit("get_data", docs);
  });

  socket.on("disconnect", () => {
    console.log("Client disconnected");
  });
});

httpServer.listen(PORT, () => console.log(`Listening on port ${PORT}`));