
const mongoose = require('mongoose');
const mongoUrl = "mongodb://localhost:27017/nodeprj_db";
mongoose.connect(mongoUrl, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useFindAndModify: false,
    useCreateIndex: true
  },(err) => {
      if(!err){
          console.log("DB Connected Successfully");
      }
  });

module.exports = mongoose;