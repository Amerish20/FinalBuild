const mongoose = require('../config/db.config');

const messageSchema = mongoose.Schema({
    content: {
        type: String,
        required: true,
    },
    createdBy: {
        type: String,
        required: true,
    },
    createdTime:{
        type:Date,
        required:true,
        default : Date.now
    }
});


module.exports = mongoose.model('Messages', messageSchema);