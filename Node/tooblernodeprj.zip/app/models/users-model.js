const mongoose = require('../config/db.config');
const bcrypt = require('bcrypt');

const usersSchema = mongoose.Schema({

    firstName: {
        type: String,
        required: true,
    },

    email: {
        type: String,
        required: true 
    },
    password: {
        type: String,
        required: true 
    },
    createdTime:{
        type:Date,
        required:true,
        default : Date.now
    },
    loginTime:{
        type:Date,
        required:true,
        default : Date.now
    },
    logoutTime:{
        type:Date,
        required:true,
        default : Date.now
    }
});

usersSchema.methods.comparePassword = function(password) {
    return bcrypt.compareSync(password, this.password);
  };


module.exports = mongoose.model('Users', usersSchema);