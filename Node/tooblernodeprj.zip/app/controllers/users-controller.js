const UsersModel = require("../models/users-model");
const bodyParser = require('body-parser');
var jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const config = require("../config/config");
const fs = require('fs')

const create = async(req,res) => {
    try{
        var saveData = new UsersModel({
            firstName:req.body.name,
            email:req.body.email,
            password: await bcrypt.hashSync(req.body.password, 10),
        });
        //saveData.password = bcrypt.hashSync(req.body.password, 10);
        saveData.save(function(err, user) {
            if (err) {
            res.json({'error' : err,'status_code' : 400});
            } else {

            var d = new Date();
            var n = 'at '+d.toLocaleTimeString();
            var namelogin = req.body.name;
            var type = 'signup';
            var obj = {type: type, name:namelogin,msgtime:n}
            var jsondata = JSON.stringify(obj);
            fs.writeFile('data.json', jsondata, err => {
                if (err) {
                    console.error(err)
                    return
                }
            })
            //user.password = undefined;
            //res.json({'result' : user,'status_code' : 200});
            res.redirect("/login");
            }
        });
    }catch(error){
        console.log(error)
    }
};


const getAll = async(req,res) => {
    var findAllData = await UsersModel.find();
    res.json(findAllData);
       
};


const login = async(req,res) => {
         
         if(!req.body.email){
            return res.json({'error' : { message: 'email missing..!'},'status_code' : 400});
        }
        if(!req.body.password){
            return res.json({'error' : { message: 'Password missing..!'},'status_code' : 400});
        }
        await UsersModel.findOne({'email': req.body.email}, function(err, user) {
            sess = req.session;
            sess.email = req.body.email;
            if (err) {
                return res.json({'error' : err,'status_code' : 400});
            }
            if (!user || !user.comparePassword(req.body.password)) {
                return res.json({'error' : { message: 'Authentication failed. Invalid user or password.'},'status_code' : 400});
            }
            var d = new Date();
            var n = 'at '+d.toLocaleTimeString();
            var namelogin = user.firstName;
            var type = 'login';
            var obj = {type: type, name:namelogin,msgtime:n}
            var jsondata = JSON.stringify(obj);
            fs.writeFile('data.json', jsondata, err => {
                if (err) {
                  console.error(err)
                  return
                }
            })
            // let data = {
            //     firstName : user.firstName,
            //     email : user.email,
            //     password:user.password,
            //     createdTime:user.createdTime,
            // }
            sess.name = user.firstName;
            const accessToken = 'JWT '+jwt.sign({ "body": user._id }, config.TOKEN_SECRET, { algorithm: 'HS256'});

            // var id = user._id;
            // var updateData = UsersModel.updateMany({_id:id},{$set:{
            //     data
            // }});

            // res.json({ 
            //     "result":{
            //         ...data
            //     }, 
            //     "status_code": 200 
            // });
            res.redirect("/dashboard");
        });
};

const logout = async(req,res) => {
    sess = req.session;
    await UsersModel.findOne({'email': sess.email}, function(err, user) {
        let data = {
            firstName : user.firstName,
            email : user.email,
            password:user.password,
            createdTime:user.createdTime,
            loginTime:user.loginTime,
            logoutTime:new Date()
        }
        var id = user._id;
        var updateData = UsersModel.updateMany({_id:id},{$set:{
                data
        }});

    });
    res.redirect("/");


};

const deleteall = async(req,res) => {
    var deleteAllData = await UsersModel.deleteMany().then(e => {
        res.json({message:"Deleted all data successfully"});
    });
}

module.exports = {
    create,
    login,
    logout,
    deleteall,
    getAll
    
}
