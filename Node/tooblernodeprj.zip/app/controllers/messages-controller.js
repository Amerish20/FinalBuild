const MessageModel = require("../models/messages-model");
const bodyParser = require('body-parser');

const create = async(req,res) => {
    try{
        sess = req.session;
        var saveData = new MessageModel({
            content:req.body.content,
            createdBy:sess.name,
            
        });
        saveData.save(function(err, user) {
            if (err) {
            res.json({'error' : err,'status_code' : 400});
            } else {
            var n = 'a message';
            var namelogin = sess.name;
            var type = 'create';
            var obj = {type: type, name:namelogin,msgtime:n}
            var jsondata = JSON.stringify(obj);
            fs.writeFile('data.json', jsondata, err => {
                if (err) {
                    console.error(err)
                    return
                }
            })
            //res.json({'result' : user,'status_code' : 200});
            res.redirect("/listmsg");
            }
        });
    }catch(error){
        console.log(error)
    }
};


const getAllMsg = async(req,res) => {
    var findAllData = await MessageModel.find();
    res.json(findAllData);
       
};

const updatemsg = async(req,res) => {
    var id = req.params.id;
    var findByIdData = await MessageModel.findById(id);
    res.render('editmsg', {'result': findByIdData});
       
};


const editmsgsubmit = async(req,res) => {
    var updateData = await MessageModel.updateOne({_id:req.body.id},{$set:{
        content:req.body.content,
        createdBy:req.body.name

    }});
    res.redirect("/listmsg");
};

const deleteallMsg = async(req,res) => {
    var deleteAllData = await MessageModel.deleteMany().then(e => {
        res.json({message:"Deleted all data successfully"});
    });
}


const deleteonemsg = async(req,res) => {
    var id = req.params.id;
    var n = 'a message';
    var namelogin = sess.name;
    var type = 'delete';
    var obj = {type: type, name:namelogin,msgtime:n}
    var jsondata = JSON.stringify(obj);
    fs.writeFile('data.json', jsondata, err => {
        if (err) {
            console.error(err)
            return
        }
    })
    var deleteData = await MessageModel.findByIdAndRemove(id).then(e => {
        res.redirect("/listmsg");
    });
       
};

const listmsg = async(req,res) => {
    var findAllData = await MessageModel.find();
    //res.json(findAllData);
    res.render('listmsg', {'result': findAllData});
       
};



module.exports = {
    create,
    getAllMsg,
    updatemsg,
    deleteallMsg,
    deleteonemsg,
    listmsg,
    editmsgsubmit
    
    
}
