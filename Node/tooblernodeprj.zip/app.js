const express = require('express');
const app = express();
const PORT = 8080;
//const PORT = process.env.PORT || 9000;
const http = require("http");
const cors = require("cors");
const fs = require('fs')
const bodyParser = require('body-parser');
const session = require('express-session');
const SignupController = require('./app/controllers/users-controller');
const MessageController = require('./app/controllers/messages-controller');

app.set("view engine", "ejs");
app.use(cors());
app.use(session({secret: 'a123zxy',saveUninitialized: true,resave: true}));
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: false }))

const httpServer = http.createServer(app);
const io = require("socket.io")(httpServer, {
    cors: {
      origin: "http://localhost:3000",
      methods: ["GET", "POST"]
    }
});

app.get('/', function (req, res) {  
    res.render("home");  
})  
app.get('/login', function (req, res) {  
    res.render("login");  
})  
app.get('/signup', function (req, res) {  
    res.render("signup");   
})  
app.post('/signup',SignupController.create);
app.get('/getAll',SignupController.getAll);
app.post('/signin',SignupController.login);
app.get('/dashboard', function (req, res) {  
    res.render("dashboard");  
}) 

app.get('/logout',SignupController.logout);
app.get('/deleteall',SignupController.deleteall);
app.get('/createmsg', function (req, res) {  
    res.render("createmsg");   
}) 
app.post('/msgcreatesubmit',MessageController.create);
app.get('/getAllMsg',MessageController.getAllMsg);
app.get('/listmsg',MessageController.listmsg);
app.get('/deleteallMsg',MessageController.deleteallMsg);
app.get('/deleteonemsg/:id',MessageController.deleteonemsg);
app.get('/updatemsg/:id',MessageController.updatemsg);
app.post('/editmsgsubmit',MessageController.editmsgsubmit);

// app.listen(PORT,() => {
//     console.log('My server is running on port '+PORT);
// });


// let interval;

// io.on("connection", (socket) => {
//   console.log("New client connected");
//   if (interval) {
//     clearInterval(interval);
//   }
//   interval = setInterval(() => getApiAndEmit(socket), 1000);

//   socket.on('FromAPI', function(){
//     console.log('a user connected');
//   });

//   socket.on("disconnect", () => {
//     console.log("Client disconnected");
//     clearInterval(interval);
//   });
// });



// const getApiAndEmit = socket => {
//   const response = new Date();
//   socket.emit("FromAPI", response);
// };

io.on("connection", (socket) => {
    console.log("New client connected");
    const data = '';
    socket.on('initial_data', () => {
      const data = fs.readFileSync('data.json')
      const docs =  JSON.parse(data);
      if(docs.type == 'login'){
        finaldoc = docs.name+' '+docs.type+' '+docs.msgtime;
      } else if(docs.type == 'signup'){
        finaldoc = docs.name+' '+docs.type+' '+docs.msgtime;
      } else if(docs.type == 'create'){
        finaldoc = docs.name+' '+docs.type+' '+docs.msgtime;
      } else if(docs.type == 'delete'){
        finaldoc = docs.name+' '+docs.type+' '+docs.msgtime;
      }
      fs.writeFile('data.json', '', err => {
        if (err) {
          console.error(err)
          return
        }
      })
      console.log(finaldoc)
      io.sockets.emit("get_data", finaldoc);
    });
  
    socket.on("disconnect", () => {
      console.log("Client disconnected");
    });
  });

httpServer.listen(PORT, () => console.log(`Listening on port ${PORT}`));
