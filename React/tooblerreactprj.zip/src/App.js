import React, { useState, useEffect } from "react";
import socketIOClient from "socket.io-client";
import './App.css';


const ENDPOINT = "http://localhost:8085";

function App() {
  const [response, setResponse] = useState([]);
  useEffect(() => {
    const socket = socketIOClient(ENDPOINT);
    socket.emit("initial_data");
    socket.on("get_data", data => {
      console.log(data)
      setResponse(data);
    });
  }, []);
  
  return (
    <div className="App">
      <br></br>
     {response}
    </div>
  );
}

export default App;
